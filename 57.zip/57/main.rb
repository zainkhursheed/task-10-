# main.rb
require_relative 'Army'
require_relative 'squad'
require_relative 'Hero'
require_relative 'Monster'
require_relative 'EnhancedUnit'
require_relative 'Unit'
require_relative 'Upgrade'
require 'stringio'

def capture_output
  begin
    output = StringIO.new
    $stdout = output
    yield
    output.string
  ensure
    $stdout = STDOUT
  end
end

def process_input(input_file)
  army = nil
  squad = nil
  enhanced_unit = nil
  unit = nil

  File.foreach(input_file) do |line|
    parts = line.strip.split("\t").reject(&:empty?)
    next if parts.empty?

    case parts[0]
    when "Army:"
      army_name = parts[1] || "Army Name"
      player_name = parts[2] || "Player Name"
      faction_name = parts[3] || "Faction Name"
      army = Army.new(army_name, player_name, faction_name)
      puts "Creating Army: #{army_name}, #{player_name}, #{faction_name}"
      puts "\t#{army}"

    when "Squad:"
      squad_name = parts[1] || "Squad Name"
      squad = Squad.new(squad_name)
      army.addUnit(squad) if army
      puts "Creating Squad: #{squad_name}"
      puts "\t#{squad}"
      puts "Adding Squad to Army"
      puts "\t#{army}"

    when "Hero:"
      hero_name = parts[1] || "Hero Name"
      points = (parts[2] || 100).to_i
      hero = Hero.new(hero_name, points)
      squad.addUnit(hero) if squad
      puts "Creating Hero: #{hero_name}, #{points}"
      puts "\t#{hero}"
      puts "Adding Hero to Squad"
      puts "\t#{squad}"

    when "Monster:"
      monster_name = parts[1] || "Monster Name"
      points = (parts[2] || 100).to_i
      monster = Monster.new(monster_name, points)
      squad.addUnit(monster) if squad
      puts "Creating Monster: #{monster_name}, #{points}"
      puts "\t#{monster}"
      puts "Adding Monster to Squad"
      puts "\t#{squad}"

    when "Enhanced Unit:"
      enhanced_name = parts[1] || "Enhanced Unit Name"
      points = (parts[2] || 100).to_i
      special_rule = parts[3] || "Special Rule"
      enhanced_unit = EnhancedUnit.new(enhanced_name, points)
      enhanced_unit.specialrule = special_rule
      squad.addUnit(enhanced_unit) if squad
      puts "Creating Enhanced Unit: #{enhanced_name}, #{points}"
      puts "\t#{enhanced_unit}"
      puts "Adding Enhanced Unit to Squad"
      puts "\t#{squad}"

    when "Special Rule:"
      new_rule = parts[1] || "Special Rule Update"
      if enhanced_unit
        puts "Adding special rule #{new_rule} to #{enhanced_unit}"
        enhanced_unit.specialrule = new_rule
        puts "Added special rule #{new_rule} to #{enhanced_unit}"
      end

    when "Unit:"
      unit_name = parts[1] || "Name"
      points = (parts[2] || 100).to_i
      unit = Unit.new(unit_name, points)
      squad.addUnit(unit) if squad
      puts "Creating Unit: #{unit_name}, #{points}"
      puts "\t#{unit}"
      puts "Adding Unit to Squad"
      puts "\t#{squad}"

    when "Upgrade:"
      upgrade_name = parts[1] || "Upgrade Name"
      points = (parts[2] || 100).to_i
      upgrade = Upgrade.new(upgrade_name, points)
      if unit
        unit.addUpgrade(upgrade)
        puts "Creating Upgrade: #{upgrade_name}, #{points}"
        puts "\t#{upgrade}"
        puts "Adding Upgrade to Unit"
        puts "\t#{unit}"
      end
    end
  end

  puts "Summary of final units"
  puts "Last army: #{army}" if army
  puts "Last squad: #{squad}" if squad
  puts "Last enhanced unit: #{enhanced_unit}" if enhanced_unit
  puts "Last unit: #{unit}" if unit
end

if __FILE__ == $0
  input_file = ARGV[0]
  output_file = ARGV[1]
  output = capture_output { process_input(input_file) }
  File.write(output_file, output)
end
