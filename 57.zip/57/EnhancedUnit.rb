# EnhancedUnit.rb
require_relative 'Unit'

class EnhancedUnit < Unit
  attr_accessor :specialrule

  def initialize(name, points)
    super(name, points)
    @specialrule = "Special Rule"
  end

  def to_s
    "#{@name} (#{total_points}, #{@quality}, #{@defence}) special rule: [#{@specialrule}]"
  end
end
