# Squad.rb
class Squad
  attr_accessor :name, :units

  def initialize(name)
    @name = name
    @units = []
  end

  def addUnit(unit)
    @units << unit
  end

  def total_points
    @units.map(&:total_points).sum
  end

  def to_s
"#{@name} (#{total_points}, 2, 2) units: #{@units.map(&:to_s).join(' ')}"
  end
end
