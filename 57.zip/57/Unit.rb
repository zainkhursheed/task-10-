# Unit.rb
class Unit
  attr_accessor :name, :points, :quality, :defence, :upgrades

  def initialize(name, points)
    @name = name
    @points = points
    @quality = 2
    @defence = 2
    @upgrades = []
  end

  def addUpgrade(upgrade)
    @upgrades << upgrade
  end

  def total_points
    @points + @upgrades.map(&:points).sum
  end

  def to_s
    if @upgrades.empty?
      "#{@name} (#{total_points}, #{@quality}, #{@defence})"
    else
      "#{@name} (#{total_points}, #{@quality}, #{@defence}) upgrades: [#{@upgrades.map(&:to_s).join(', ')}]"
    end
  end
end
