# Army.rb
class Army
  attr_accessor :army_name, :player_name, :faction_name, :units

  def initialize(army_name, player_name, faction_name)
    @army_name = army_name
    @player_name = player_name
    @faction_name = faction_name
    @units = []
  end

  def addUnit(unit)
    @units << unit
  end

  def total_points
    @units.map(&:total_points).sum
  end

  def to_s
    "Player: #{@player_name}, faction: #{@faction_name}, army: #{@army_name} (#{total_points}, 2, 2) units: " \
  "#{@units.map(&:to_s).join(' ')}"

  end
end
