# Hero.rb
require_relative 'Unit'

class Hero < Unit
  def initialize(name, points)
    super(name, points)
    @quality = 5
    @defence = 5
  end
end
