# Monster.rb
require_relative 'Unit'

class Monster < Unit
  def initialize(name, points)
    super(name, points)
    @quality = 4
    @defence = 4
  end
end
