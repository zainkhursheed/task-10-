# Upgrade.rb
class Upgrade
  attr_accessor :name, :points

  def initialize(name, points)
    @name = name
    @points = points
  end

  def to_s
    "#{@name} (#{@points})"
  end
end
