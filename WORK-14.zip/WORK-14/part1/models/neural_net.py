from typing import Sequence
import numpy as np

class MyNeuralNetwork:
    """In this file, you'll implement your own multi-layer perceptron (aka a fully connected network). 
    The net you'll implement has input dimension N, hidden layer dimension of H, and output dimension C. 
    Your network will use a ReLU after each fully connected layer (except for the output).
    We'll pass the outputs of the last fully-connected layer through a sigmoid.
    """

    def __init__(
        self,
        input_size: int,
        hidden_sizes: Sequence[int],
        output_size: int,
        num_layers: int
    ):
        """This initializes the model.
        Weights and biases are in self.params which has the form:
        W1: 1st layer weights; has shape (D, H_1)
        b1: 1st layer biases; has shape (H_1,)
        ...
        Wk: kth layer weights; has shape (H_{k-1}, C)
        bk: kth layer biases; has shape (C,)
        Parameters:
            input_size: The dimension of input
            hidden_size: List with the number of neurons per hidden layer
            output_size: output dimension C
            num_layers: Number of layers
        """
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.num_layers = num_layers

        assert len(hidden_sizes) == (num_layers - 1)
        sizes = [input_size] + hidden_sizes + [output_size]

        self.params = {}
        for i in range(1, num_layers + 1):
            # this is initializing the weights
            self.params["W" + str(i)] = np.random.randn(sizes[i - 1], sizes[i]) / np.sqrt(sizes[i - 1])
            self.params["b" + str(i)] = np.zeros(sizes[i])

    def linear(self, W: np.ndarray, X: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Fully connected layer.
        Parameters:
            W: the weights
            X: the input data
            b: the bias
        Returns:
            the output
        """
        # TODO: implement me
        return
    
    def linear_gradient(self, W: np.ndarray, X: np.ndarray, b: np.ndarray, de_dz: np.ndarray, reg, N) -> np.ndarray:
        """Gradient of linear layer
            returns de_dw, de_db, de_dx (what's this called?)
        """
        # TODO: implement me
        return 

    def relu(self, X: np.ndarray) -> np.ndarray:
        """Rectified Linear Unit (ReLU).
        Parameters:
            X: the input data
        Returns:
            the output
        """
        # TODO: implement me
        return

    def relu_gradient(self, X: np.ndarray) -> np.ndarray:
        """Gradient of ReLU.
        Parameters:
            X: the input data
        Returns:
            the output data
        """
        # TODO: implement me
        return

    def sigmoid(self, x: np.ndarray) -> np.ndarray:
        # Need to implement this (also, might want to use some numerical stability tricks if you want)
        return

    def sigmoid_gradient(self, X: np.ndarray) -> np.ndarray:
        # TODO 
        return

    def mse(self, y: np.ndarray, p: np.ndarray) -> np.ndarray:
        # TODO 
        return
    
    def mse_gradient(self, y: np.ndarray, p: np.ndarray) -> np.ndarray:
        # TODO
        return
    
    def mse_sigmoid_gradient(self, y: np.ndarray, p: np.ndarray) -> np.ndarray:
        # TODO
        return

    def forward(self, X: np.ndarray) -> np.ndarray:
        """
        Parameters:
            X: Input data.
        Returns:
            Matrix of shape (N, C) (number of samples x output dim)
        """
        self.outputs = {}
        
        # TODO - you need to implement this. Hint: you'll be calling other functions in here.
        
        return

    def backward(self, y: np.ndarray) -> float:
        """Perform backprop and compute losses.
        Parameters:
            y: target values
        Returns:
            Loss for this batch
        """
        self.gradients = {}
        
        # TODO
        
        return

    def update(
        self,
        lr: float = 0 
    ):
        """Update the model parameters using SGD 
        Parameters:
            lr: Learning rate
        """
        # TODO - you'll be implementing SGD in here
        return

        # C